طريقة التشغيل (مرة واحدة، 5 دقائق)
1) افتح script.google.com > مشروع جديد.
2) انسخ محتوى Code.gs إلى الملف الافتراضي Code.gs.
3) أضف ملف HTML جديداً بالاسم  index  والصق فيه محتوى index.html كاملاً.
4) (اختياري) Project Settings > أظهر appsscript.json والصق محتواه.
5) شغّل الدالة setup واقبل الصلاحيات، ثم من View > Logs انسخ ADMIN_KEY.
6) Deploy > New deployment > Web app: Execute as = Me، Who has access = Anyone. انسخ الرابط (ينتهي بـ /exec).
7) للإدارة افتح:  الرابط/exec?k=ADMIN_KEY  (احفظه كإشارة مرجعية). أول دخول: admin / admin ثم غيّر كلمة المرور.
8) رابط تسجيل الناخبين العام (يظهر أيضاً في تبويب الإعدادات):  الرابط/exec?intake=1
   رابط المتابعة للمراقبين:  الرابط/exec?watch=1
عند أي تعديل على index.html: الصقه ثم Deploy > Manage deployments > Edit > New version.
مهم: Code.gs تغيّر (أضيفت الدالة rpc). الصقه كاملاً ثم Deploy > Manage deployments > Edit > New version، وإلا بقيت الصفحات على النسخة القديمة.
صفحة التسجيل المستقلة (خفيفة وسريعة): أضف في Apps Script ملف HTML جديداً بالاسم intake والصق فيه intake.html كاملاً، ثم انشر نسخة جديدة. بعدها رابط ?intake=1 يفتح هذه الصفحة وتصل الطلبات تلقائياً إلى تبويب «الطلبات».
لاستضافتها خارج Google (GitHub Pages أو صانع تطبيق): ارفع intake.html وافتحه بالرابط:  رابط-الصفحة/intake.html?g=رابط-Apps-Script-/exec
